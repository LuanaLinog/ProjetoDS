﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDSLuana
{
    public partial class frmUsuario : Form
    {
        public frmUsuario()
        {
            InitializeComponent();
        }

        private void frmUsuario_Load(object sender, EventArgs e)
        {
            txtEmail.Enabled = false;
            txtSenha.Enabled = false;
            btnSalvar.Enabled = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            txtEmail.Enabled = true;
            txtSenha.Enabled = true;
            btnSalvar.Enabled = true;
            txtEmail.Focus();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bddecoracao;uid=root;pwd=''");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;
            comando.CommandText = ("insert into usuario(login,senha) values (@login,@senha)");
            comando.Parameters.AddWithValue ("@login",txtEmail.Text);
            comando.Parameters.AddWithValue ("@senha",txtSenha.Text);
            conn.Open();
            comando.ExecuteNonQuery();
            MessageBox.Show("Usuário cadastrado com sucesso");
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }
    }
}
