﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProjetoDSLuana
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnVerificacao_Click(object sender, EventArgs e)
        {
            String login;
            MySqlDataReader reg = null;
            MySqlConnection conn = new MySqlConnection("server=localhost;database=bddecoracao;uid=root;pwd=");
            MySqlCommand comando = new MySqlCommand();
            comando.Connection = conn;


            comando.CommandText = "SELECT * FROM usuario WHERE login = @login AND Senha = @senha";
            comando.Parameters.AddWithValue("@login", txtLogin.Text);
            comando.Parameters.AddWithValue("@senha", txtSenha.Text);
            conn.Open();
            reg = comando.ExecuteReader();

            if (reg.Read())
            {

                login = reg["login"].ToString();
                MessageBox.Show("Acesso permitido! Usuário logado");

                frmMenu menu = new frmMenu();
                this.Hide();
                menu.ShowDialog();

            }
            else
            {
                MessageBox.Show("Login/Usuário não conferem");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            this.Hide();
        }
    }
}
